package pl.klima7;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = openOrCreateDatabase("test.sqlite",MODE_PRIVATE,null);
        db.execSQL("create table if not exists test(id integer primary key autoincrement, name text)");
    }

    public void Save(View view) {
        EditText dane = findViewById(R.id.text_editable);
        if (!dane.getText().toString().equals("")) {
            db.execSQL("insert into test (name) values('" + dane.getText().toString() + "')");
        }
    }

        public void Read(View view) {
            TextView wynik = findViewById(R.id.output);
            Cursor cursor = db.rawQuery("select name from test order by id desc limit 1", null);
            if(cursor.moveToNext()) {
                do {
                    wynik.setText(cursor.getString(0));
                }while (cursor.moveToNext());
            }
        }

    public void press_button(View view) {
        Save(view);
        Read(view);
    }
}