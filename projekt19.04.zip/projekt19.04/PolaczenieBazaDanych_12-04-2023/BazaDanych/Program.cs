﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BazaDanych
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // (new Program()).CreateMySqlDataReader("select * from actor limit 10");
            String qry = "insert into actor(first_name, last_name, last_update) values('Jan', 'Nowak', now())";
            (new Program()).MySqlInsert(qry);
        }

        public void CreateMySqlDataReader(string mySelectQuery)
        {
            MySqlConnection myConnection = new MySqlConnection();
            myConnection.ConnectionString = "Persist Security Info=False;database=sakila;server=localhost;Connect Timeout=30;user id=root; pwd=";
            MySqlCommand myCommand = new MySqlCommand(mySelectQuery, myConnection);
            myConnection.Open();
            MySqlDataReader myReader;
            myReader = myCommand.ExecuteReader();
            try
            {
                while (myReader.Read())
                {
                    Console.Write(myReader.GetInt64(0) + "; ");
                    Console.Write(myReader.GetString(1) + " ");
                    Console.WriteLine(myReader.GetString(2));
                }
            }
            catch (Exception blad)
            {
                Console.WriteLine(blad.Message);
            }
            finally
            {
                myReader.Close();
                myConnection.Close();
            }
        }

        private void MySqlInsert(String mySelectQuery)
        {
            MySqlConnection myConnection = new MySqlConnection();
            myConnection.ConnectionString = "Persist Security Info=False;database=sakila;server=localhost;Connect Timeout=30;user id=root; pwd=";
            MySqlCommand myCommand = new MySqlCommand(mySelectQuery, myConnection);
            myConnection.Open();
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception msg)
            {
                Console.WriteLine(msg.Message);
            }
            finally
            {
                myConnection.Close();
            }
        }
    }
}
