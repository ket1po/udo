package pl.opitek;
import  androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    private SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = openOrCreateDatabase("test.sqlite", MODE_PRIVATE,null);
        db.execSQL("create table if not exists test (id integer primary key autoincrement, name text)");


    }

    public void start(View view) {
        EditText dane = findViewById(R.id.plt1);
        if (!dane.getText().toString().equals("")) {
            db.execSQL("insert into test (name) values('"+
                    dane.getText().toString()+"')");
        }


    }


  Cursor cursor = db.rawQuery("select name from test order by id desc limit1", null);
    if(cursor.moveTonext())
    do{
      wynik.setText(cusor.getString(0));

    }while (cursor.movetoNext())

}