﻿// See https://aka.ms/new-console-template for more information

Funkcja d = new Funkcja();
d.CzytajDane();
d.PrzetorzDane();
d.WyswietlWynik();
//prostokat MyProstokat = new prostokat();
//MyProstokat.WczytajDane();
//MyProstokat.PrztworzDane();
//MyProstokat.WysiwetlWynik();
//class prostokat
//{
//    double a, b, oblicza_pole;
//    public void WczytajDane()
//    {
//        Console.WriteLine("Podaj bok a: ");
//        a = double.Parse(Console.ReadLine());
//        Console.WriteLine("Podaj bok b: ");
//        b = double.Parse(Console.ReadLine());
//    }
//    public void PrztworzDane()
//    {
//        oblicza_pole = a * b;
//    }
//    public void WysiwetlWynik()
//    {
        
//        Console.WriteLine(oblicza_pole);

//    }
//}


class Funkcja
{
    double a, b, c,x1, x2, x, delta;



    public void CzytajDane()
    {
        
        Console.WriteLine("Podaj a: ");
        a = double.Parse(Console.ReadLine());
        
            Console.WriteLine("Podaj b: ");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("Podaj c: ");
            c = double.Parse(Console.ReadLine());
        if (a==0)
        {
            Console.WriteLine("niema");
        }
        

    }

    public void PrzetorzDane()
    {
         delta = b * b - 4 * a * c;
        
        if (delta < 0)
        {
            Console.WriteLine("Nie ma miejsc zerowych");
        }
        if (delta < 0)
        {
            Console.WriteLine("Dwa miejsca");
             x1 = -b - Math.Sqrt(delta) / 2 * a;
             x2 = -b + Math.Sqrt(delta) / 2 * a;
        }
        else
        {
            x = -b / 2 * a;
        }
    }

    public void WyswietlWynik()
    {
        if (delta == 0)
        {
            Console.WriteLine(x);
        }
        else if(delta < 0)
        {
            Console.WriteLine(x1);
            Console.WriteLine(x2);
        }
        else
        {
            Console.WriteLine("błąd");
        }
    }
}