package pl.opitek.coffeina;
import pl.opitek.coffeina.R;

public class Drink {
    private String name;
    private String discription;
    private int imageResourcedId;

    public static final  Drink[] drinks = {
            new Drink("Latte", "Czarne espresso z gorącym mlekiem i mleczną pianką.", R.drawable.latte),
            new Drink("Cappuccino", "Czarne espresso z dużą ilością spienionego mlekoa.", R.drawable.cappuccino),
            new Drink("Espresso", "Czarna kawa ze świeżo mielonch ziarnem najwyższej jakości.", R.drawable.filter)
    };

    private Drink(String name, String description, int ImageResourcedId) {
        this.name = name;
        this.discription = description;
        this.imageResourcedId = imageResourcedId;
    }

    public String getDiscription() {
        return discription;
    }

    public String getName() {
        return name;
    }

    public int getImageResourcedId() {
        return imageResourcedId;
    }

    public String toString() {
        return this.name;
    }
}


