﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSTeoria
{
    internal class Program
    {
        private static object odpowiedz;

        static void Main(string[] args)
        {

            // WypiszL();
            // WypiszS();
            // WypiszT();
            // CzyP();
            // O();


            // Dz();
            // D();
            // PrzypisywanieZ();
            // InkrementacjaD();
            // NiejawneO();
            // Console.WriteLine(dodawanie(1, 2));
            // p();
            // parz();
            lit();
        }
        static void WypiszL()
        {
            ///<summary>Wypisanie zmiennej</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 24.10.2022
            /// </remarks>
            int Zm = 12;
            Console.WriteLine(Zm);
        }

        static void WypiszS()
        {
            ///<summary>Wypisanie zmiennej typu string</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 24.10.2022
            /// </remarks>
            string Te;
            Te= "String";
            Console.WriteLine(Te);
        }

        static void WypiszT()
        {
            ///<summary>Wypisanie zmiennej typu string z liczby zmiennoprzecinkowej</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 24.10.2022
            /// </remarks>
            float Lic = 0.5f;
            string Tek = Lic.ToString();
            Console.WriteLine(Tek);
        }

        static void CzyP()
        {
            ///<summary>Wypisanie zmiennej typu boolean</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 24.10.2022
            /// </remarks>
            bool Pr = true;
            Console.WriteLine(Pr);
        }

        static void O()
        {
            ///<summary>Wypisanie zmiennej typu char</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 24.10.2022
            /// </remarks>
            char Lit= 'K';
            Console.WriteLine(Lit + 7);
        }

        static void Dz()
        {
            ///<summary>Wypisanie wartości wyniku dzielenia</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 24.10.2022
            /// </remarks>
            Console.WriteLine(3.0 / 1.0);
            Console.WriteLine(3 / 1);
        }

        static void D()
        {
            ///<summary>Wypisanie dodawania zmiennych w typie string oraz int</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 24.10.2022
            /// </remarks>
            String je = "1";
            String dw = "2";
            Console.WriteLine(je + dw);
            Console.WriteLine(int.Parse(je) + int.Parse(dw));
        }

        static void PrzypisywanieZ()
        {
            ///<summary>Przypisanie i wypisanie zmiennych</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 24.10.2022
            /// </remarks>
            int Zm = 10;
            int Zm2;
            Console.WriteLine(Zm);
            Zm = Zm2 = 5;
            Console.WriteLine(Zm);
        }

        static void InkrementacjaD()
        {
            ///<summary>Inkrementacja, dekrementacja oraz wypisanie zmiennych</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 24.10.2022
            /// </remarks>
            float Li = 1.5f;
            Console.WriteLine(Li);
            Li++;
            Console.WriteLine(Li);
            Li--;
            Console.WriteLine(Li);
        }

        static void NiejawneO()
        {
            ///<summary>Niejawne zadeklarowanie zmiennej</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 24.10.2022
            /// </remarks>
            var z = 6;
        }
        
        static void pokazRezultat(int odpowiedz)
        {
            ///<summary></summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 14.11.2022
            /// </remarks>
            Console.WriteLine($"Odpowiedż to {odpowiedz}");
            return;
        }

        static int dodawanie(int pierwsza, int druga)
        {
            ///<summary>zwaraca dane przez metodę</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 14.11.2022
            /// </remarks>
            return pierwsza + druga;
        }

        static int dodawanie2(int pierwsza, int druga) => pierwsza + druga;
        ///<summary>Prostrza metoda</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 21.11.2022
            /// </remarks>

        static void pokazRezultat2(int odpoweidz)=> Console.WriteLine($"Odpowiedz brzmi{odpowiedz}.");
        ///<summary></summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 21.11.2022
            /// </remarks>
            
          static  (int,int) zwracaWieleWynikow()
    {
            ///<summary>Metoda zwraca wiele wartosci</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 21.11.2022
            /// </remarks>
        int a = 5;
        int b = 3;
        return(a,b);
    }

    static void obsugaWieluWynikow()
         {
            ///<summary>Metoda zwraca wiele wartosci</summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 21.11.2022
            /// </remarks>
        int c, d;
        (c, d) = zwracaWieleWynikow();

        }

        static void p()
        {
            ///<summary>Wyswietla liczby od 1 do 10 </summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 27.02.2023
            /// </remarks>
            int i = 0;
            while (i < 10)
            {
                Console.WriteLine(i++);
                
            }
        }

        static void parz()
        {
            ///<summary>Wyswietla tylko parzyste liczby od 1 do 20 </summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 27.02.2023
            /// </remarks>
            int i = 1;
            while (i < 20)
            {
               if (i % 2==0)
                {
                    Console.WriteLine(i);

                }
                
            }
        }

        static void lit()
        {
            ///<summary>Wyswietla co 2 litere z podanego przez uzytkownika miasto </summary>
            ///<remarks>Autor: Adam Opitek
            ///Data: 27.02.2023
            /// </remarks>
            string tekst = "";
            Console.WriteLine("podaj miasto: ");
            tekst = Console.ReadLine();
            int dlugosc = tekst.Length;
            for (int i =0; i < dlugosc; i+=2)
            {
                Console.WriteLine(tekst[i]);
            }
        }


    }

    

  

}
