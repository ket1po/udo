﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cwiczenia_parametry_opcjonalne
{
    internal class Program
    {
        static void Main(string[] args)
        {
            (new Program()).run();
        }
        void run()
        {
            double fee = calculateFee(DailyRate: 375.0);
            Console.WriteLine($"'fee is {fee}");
        }

        private double calculateFee(double theDailyRate = 500.0, int onOfDays = 1)
        {
            Console.WriteLine("calculateFee using two optional parameters");
            return theDailyRate * onOfDays;
        }

        private double calculateFee(double DailyRate = 500.0)
        {
            Console.WriteLine("calculateFee using two optional parameters");
            int defaultNoOfDays = 1;
            return DailyRate * defaultNoOfDays;
        }

        private double calculateFee()
        {
            Console.WriteLine("calculateFee using hardcoded values");
            double defaultDailyRate = 400.0;
            int defaultNoOfDays = 1;
            return defaultDailyRate * defaultNoOfDays;
        }
    }
}
