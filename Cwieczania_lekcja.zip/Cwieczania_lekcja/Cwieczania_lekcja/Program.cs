﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cwieczania_lekcja
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //cw1();
            //cw2();
            //cw3();
            cw4();
        }

        static void cw1()
        {
            int a, b;
            Console.WriteLine("podaj liczbe");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("podaj druga liczbe");
            b = int.Parse(Console.ReadLine());
            Console.WriteLine(a + b);
        }

        static void cw2()
        {
            int a, b;
            try
            {
                Console.WriteLine("podaj liczbe");
                a = int.Parse(Console.ReadLine());
                Console.WriteLine("podaj druga liczbe");
                b = int.Parse(Console.ReadLine());
                Console.WriteLine(a + b);
            }
            catch (FormatException blad)
            {
                Console.WriteLine(blad.Message);
            }
        }

        static void cw3()
        {
            int a, b;
            try
            {
                Console.WriteLine("podaj liczbe");
                a = int.Parse(Console.ReadLine());
                Console.WriteLine("podaj druga liczbe");
                b = int.Parse(Console.ReadLine());
                Console.WriteLine(a + b);
            }
            catch (FormatException blad)
            {
                Console.WriteLine("Tu błedny jest format");
                Console.WriteLine(blad.Message);
            }
            catch(OverflowException blad)
            {
                Console.WriteLine("Tu błedny jest rozmiar");
                Console.WriteLine(blad.Message);
            }
            catch (Exception blad)
            {
                Console.WriteLine("Wszytskie pozostałe błędy");
                Console.WriteLine(blad.Message);
            }
        }
        

        static void cw4()
        {
            bool test = false;
            int a, b;
            try
            {
                Console.WriteLine("podaj liczbe");
                a = int.Parse(Console.ReadLine());
                Console.WriteLine("podaj druga liczbe");
                b = int.Parse(Console.ReadLine());
                test = true;
                Console.WriteLine(a / b);
            }
            catch (Exception blad) when (test)
            {
                Console.WriteLine(blad.Message);
            }
        }

        
    }
}
