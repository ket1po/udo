﻿using System.Windows;
using Microsoft.Win32;
using System.IO;

namespace notatnik
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private OpenFileDialog openFileDialog;
        string sciezkaPliku = null;
        private SaveFileDialog saveFileDialog;

        public MainWindow()
        {
            InitializeComponent();
            openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Wybierz plik tekstowy";
            openFileDialog.DefaultExt = "txt";
            openFileDialog.Filter = "Pliki tekstowe(*.txt)|*.txt|Pliki XML (*.xml)|*.xml | Pliki źródłowe(*.cs) | *.cs|Wszytskie Pliki (*.*) | *.*";
            openFileDialog.FilterIndex = 1;

            saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "zapisz plik tekstowy";
            saveFileDialog.DefaultExt = "txt";
            saveFileDialog.Filter = openFileDialog.Filter;
            saveFileDialog.FilterIndex = 1;
        }
        

        private void MenuItem_Otworz_Click(object sender, RoutedEventArgs e)
        {
            
            if (!string.IsNullOrWhiteSpace(sciezkaPliku))
            {
                
                openFileDialog.InitialDirectory = Path.GetDirectoryName(sciezkaPliku);
                openFileDialog.FileName = Path.GetFileName(sciezkaPliku);
            }
            bool? wynik = openFileDialog.ShowDialog();
            if(wynik.HasValue && wynik.Value)
            {
                sciezkaPliku = openFileDialog.FileName;
                tb1.Text = File.ReadAllText(sciezkaPliku);
                txtStatus.Text = Path.GetFileName(sciezkaPliku);
            }
        }
    

        private void MenuItem_ZapiszJako_Click(object sender, RoutedEventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(sciezkaPliku))
            {

                saveFileDialog.InitialDirectory = Path.GetDirectoryName(sciezkaPliku);
                saveFileDialog.FileName = Path.GetFileName(sciezkaPliku);
            }
            bool? wynik = saveFileDialog.ShowDialog();
            if (wynik.HasValue && wynik.Value)
            {
                sciezkaPliku = saveFileDialog.FileName;
                File.WriteAllText(sciezkaPliku, tb1.Text);
                txtStatus.Text = Path.GetFileName(sciezkaPliku);
            }
        }

        private void MenuItem_Zakoncz_Click(object sender, System.EventArgs e)
        {

        }
    }
}
