﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace Classes
{
    class Point
    {
        private int x, y;
        public Point()
        {
            this.x = -1;
            this.y = -1;
        }
        
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public double DistanceTo(Point other)
        {
            int xDIff = this.x - other.x; 
            int yDIff = this.y - other.y;
            double  distance = Math.Sqrt(Math.Pow(xDIff,2) + Math.Pow(yDIff, 2));
            return distance;
        }

    }

}
