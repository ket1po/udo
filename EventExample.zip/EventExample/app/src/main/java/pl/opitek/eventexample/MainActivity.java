package pl.opitek.eventexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private int i = 0;

    Button button;
    TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.bt1);
        textView = findViewById(R.id.txtV1);

        button.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        i++;
                        textView.setText("Właśnie mnie kliknięto " + i + " razy");
                    }
                }
        );

        button.setOnLongClickListener(
                new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        i = i + 10;
                        textView.setText("Nastąpił długi click " + i + " razy");
                        return true;
                    }
                }
        );
    }
}