package pl.opitek.sprawdzian;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void posortuj_onClick(View view) {
        EditText l1 = findViewById(R.id.ptxt1);
        EditText l2 = findViewById(R.id.ptxt2);
        EditText l3 = findViewById(R.id.ptxt3);
        EditText l4 = findViewById(R.id.ptxt4);
        EditText l5 = findViewById(R.id.ptxt5);
        TextView wynik  = findViewById(R.id.txtv1);

        int[] tab = new int[5];
        tab[0] = parseInt(String.valueOf(l1.getText()));
        tab[1] = parseInt(String.valueOf(l2.getText()));
        tab[2] = parseInt(String.valueOf(l3.getText()));
        tab[3] = parseInt(String.valueOf(l4.getText()));
        tab[4] = parseInt(String.valueOf(l5.getText()));


        String wy = "";
        Arrays.sort(tab);
        for (int i = 0; i <5; i++) {
            wy += String.valueOf(tab[i]);
            wynik.setText(wy);

        }
    }






}