﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_figura_AdamOpitek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            figura('#', 5);
        }

        static void figura(char c, int n)
        {
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(c);
                }
                Console.WriteLine();   
            }
        }
    }
}
