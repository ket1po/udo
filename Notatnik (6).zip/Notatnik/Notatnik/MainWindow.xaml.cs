﻿using System.Windows;
using Microsoft.Win32;
using System.IO;
using System;
using System.ComponentModel;
using System.Windows.Controls;
using System.Drawing;
using System.Windows.Input;

namespace notatnik
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private OpenFileDialog openFileDialog;
        string sciezkaPliku = null;
        private SaveFileDialog saveFileDialog;
        private bool CzyTekstZmienionny = false;

        public MainWindow()
        {
            InitializeComponent();
            openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Wybierz plik tekstowy";
            openFileDialog.DefaultExt = "txt";
            openFileDialog.Filter = "Pliki tekstowe(*.txt)|*.txt|Pliki XML (*.xml)|*.xml | Pliki źródłowe(*.cs) | *.cs|Wszytskie Pliki (*.*) | *.*";
            openFileDialog.FilterIndex = 1;

            saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "zapisz plik tekstowy";
            saveFileDialog.DefaultExt = "txt";
            saveFileDialog.Filter = openFileDialog.Filter;
            saveFileDialog.FilterIndex = 1;
        }


        private void MenuItem_Otworz_Click(object sender, RoutedEventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(sciezkaPliku))
            {

                openFileDialog.InitialDirectory = Path.GetDirectoryName(sciezkaPliku);
                openFileDialog.FileName = Path.GetFileName(sciezkaPliku);
            }
            bool? wynik = openFileDialog.ShowDialog();
            if (wynik.HasValue && wynik.Value)
            {
                sciezkaPliku = openFileDialog.FileName;
                tb1.Text = File.ReadAllText(sciezkaPliku);
                txtStatus.Text = Path.GetFileName(sciezkaPliku);
                CzyTekstZmienionny = false;
            }
        }


        private void MenuItem_ZapiszJako_Click(object sender, RoutedEventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(sciezkaPliku))
            {

                saveFileDialog.InitialDirectory = Path.GetDirectoryName(sciezkaPliku);
                saveFileDialog.FileName = Path.GetFileName(sciezkaPliku);
            }
            bool? wynik = saveFileDialog.ShowDialog();
            if (wynik.HasValue && wynik.Value)
            {
                sciezkaPliku = saveFileDialog.FileName;
                File.WriteAllText(sciezkaPliku, tb1.Text);
                txtStatus.Text = Path.GetFileName(sciezkaPliku);
            }
        }

        private void MenuItem_Zapisz_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(sciezkaPliku))
            {
                File.WriteAllText(sciezkaPliku, tb1.Text);
                CzyTekstZmienionny = false;
            }
            else MenuItem_ZapiszJako_Click(sender, e);
        }



        private void MenuItem_Zakoncz_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            bool anuluj;
            ZapytajoZapisanieTekstuDoPliku(sender, out anuluj);
            e.Cancel = anuluj;
        }

        private void ZapytajoZapisanieTekstuDoPliku(object sender, out bool anuluj)
        {
            anuluj = false;
            if (CzyTekstZmienionny)
            {
                MessageBoxResult wynik =
                MessageBox.Show("Czy zapisac zmiany w edytowanym dokumencie?",
                this.Title,
                MessageBoxButton.YesNoCancel,
                MessageBoxImage.Question,
                MessageBoxResult.Cancel);
                switch (wynik)
                {
                    case
                MessageBoxResult.Yes:
                        MenuItem_Zapisz_Click(sender, null);
                        break;
                    case MessageBoxResult.No: break;
                    case MessageBoxResult.Cancel:
                    default:
                        anuluj = false;
                        break;

                }
            }
        }

        private void tb1_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            CzyTekstZmienionny = true;
        }

        private void MenuItem_Nowy_Click(object sender, RoutedEventArgs e)
        {
            bool anuluj;
            ZapytajoZapisanieTekstuDoPliku(sender, out anuluj);
            if (!anuluj) tb1.Text = "";
        }

        private void MenuItem_Cofnij_Click(object sender, RoutedEventArgs e)
        {
            tb1.Undo();
        }

        private void MenuItem_Powtorz_Click(object sender, RoutedEventArgs e)
        {
            tb1.Redo();
        }

        private void MenuItem_Usun_Click(object sender, RoutedEventArgs e)
        {
            tb1.SelectedText = "";
        }

        private void MenuItem_kopiuj_Click(object sender, RoutedEventArgs e)
        {
            tb1.Copy();
        }

        private void MenuItem_Wklej_Click(object sender, RoutedEventArgs e)
        {
            tb1.Paste();
        }

        private void MenuItem_wytnij_click(object sender, RoutedEventArgs e)
        {
            tb1.Cut();
        }

        private void MenuItemZaznaczClick(object sender, RoutedEventArgs e)
        {
            tb1.SelectAll();
        }

        private void MenuItemGodzDatClick(object sender, RoutedEventArgs e)
        {
            tb1.SelectedText = System.DateTime.Now.ToString();
        }

        private void MenuItemColorTlaClick(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItemZawijanieClick(object sender, RoutedEventArgs e)
        {
            bool CzyPozycjaZaznaczona = (sender as MenuItem).IsChecked;
            if (CzyPozycjaZaznaczona)
            {
                tb1.TextWrapping = TextWrapping.Wrap;
            }
            else
            {
                tb1.TextWrapping = TextWrapping.NoWrap;
            }
        }

        private void MenuItemPAseknarzedziClick(object sender, RoutedEventArgs e)
        {
            bool CzyPozycjaZaznaczona = (sender as MenuItem).IsChecked;
            tooBar.Visibility = CzyPozycjaZaznaczona? Visibility.Visible : Visibility.Collapsed;
        }

        private void MenuItemPasekStanuClick(object sender, RoutlledEventArgs e)
        {
            if((sender as MenuItem).IsChecked)
            {
                status1.Visibility = Visibility.Visible;
            }
            else
            {
                status1.Visibility = Visibility.Collapsed;
            }
        }

        private void ManuItemDrukujClick(object sender, RoutedEventArgs e)
        {
            printing.PrintText(tb1.Text, Font.ExtractForm(tb1);
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.F5: MenuItemGodzDatClick(sender, null); break;

            }if ((e.KeyboardDevice.Modifiers & ModifierKeys.Control) == ModifierKeys.Control) ;
            switch(e.Key)
            {
                case Key.N: MenuItem_Nowy_Click(sender, null); break;
                case Key.O: MenuItem_Otworz_Click(sender, null); break;
                case Key.S: MenuItem_Zapisz_Click(sender, null); break;
                case Key.P: ManuItemDrukujClick(sender, null); break;
            }
        }
    }
    public struct Font
     {
        public FontFamily {get; set; }
    public string FamilyName
    {
        get
        {
            return FontFamily.ToString();
        }
    }
}
