Icons made by "Edyta Czachorowska". My website: https://edithdessin.wordpress.com/
Those are free icons and you are welcome to use, modify and redistribute them.